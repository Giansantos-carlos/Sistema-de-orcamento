package com.wesleyfuchter.bankaccount.transaction

import io.quarkus.test.junit.NativeImageTest

@NativeImageTest
open class NativeTransactionResourceIT : TransactionResourceTest()